<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <main>
        <section>
            <form action="resultado.php" method="post">
                <ul>
                    <li>
                        <label for="nome">Nome</label>
                        <input type="text" name="nome" id="nome" placeholder="Fulano">
                    </li>
                    <li>
                        <label for="x">digite a nota 1</label>
                        <input type="text" name="x" id="x">
                    </li>
                    <li>
                        <label for="y">digite a nota 1</label>
                        <input type="text" name="y" id="y">
                    </li>
                    <li>
                        <label for="z">digite a nota 1</label>
                        <input type="text" name="z" id="z">
                    </li>
                    <li>
                        <input type="submit" value="adicionar">
                    </li>
                </ul>
            </form>
        </section>
    </main>
</body>
</html>